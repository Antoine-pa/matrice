# matrice
Projet de calcul matriciel avec inversion de matrices carrées de n'importe quelles dimensions et système de résolution de système d'équations à n inconnues.

# dependences
Numpy
